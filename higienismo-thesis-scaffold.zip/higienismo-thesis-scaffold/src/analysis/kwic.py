"""
Función KWIC (Key Word In Context) simple sobre texto ya limpio.
"""
from typing import List, Dict

def kwic(tokens: List[str], term: str, window: int = 8) -> List[Dict]:
    term_l = term.lower()
    out = []
    for i, tok in enumerate(tokens):
        if tok.lower() == term_l:
            left = " ".join(tokens[max(0, i - window): i])
            right = " ".join(tokens[i+1: i+1+window])
            out.append({"left": left, "term": tok, "right": right, "pos": i})
    return out
