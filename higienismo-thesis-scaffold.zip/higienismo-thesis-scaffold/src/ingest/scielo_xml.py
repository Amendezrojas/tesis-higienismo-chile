"""
Parser sencillo para XML tipo SciELO/JATS -> dict normalizado.
No requiere lxml; usa ElementTree de la librería estándar.
"""
from xml.etree import ElementTree as ET

def parse_scielo_xml(path: str) -> dict:
    tree = ET.parse(path)
    root = tree.getroot()

    def text_or_none(elem):
        return elem.text.strip() if elem is not None and elem.text else None

    # Título
    title = root.findtext(".//article-title")
    # Autores
    authors = []
    for c in root.findall(".//contrib[@contrib-type='author']"):
        surname = c.findtext(".//surname") or ""
        given = c.findtext(".//given-names") or ""
        authors.append((given + " " + surname).strip())

    # Año
    year = root.findtext(".//pub-date/year")
    # Revista
    journal = root.findtext(".//journal-title")

    # Cuerpo (texto plano concatenado)
    paragraphs = [e.text.strip() for e in root.findall(".//body//p") if e is not None and e.text]
    body_text = "\n\n".join(paragraphs) if paragraphs else ""

    return {
        "title": title,
        "authors": authors,
        "year": year,
        "journal": journal,
        "text": body_text,
        "source_format": "scielo_xml",
        "source_path": path,
    }
