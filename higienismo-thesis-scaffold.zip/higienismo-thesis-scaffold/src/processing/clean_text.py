"""
Limpieza básica de texto: normalización de espacios, minúsculas opcional,
y eliminación simple de artefactos.
"""
import regex as re

def basic_clean(s: str, lower: bool = True) -> str:
    if s is None:
        return ""
    s = re.sub(r"\s+", " ", s).strip()
    if lower:
        s = s.lower()
    return s
