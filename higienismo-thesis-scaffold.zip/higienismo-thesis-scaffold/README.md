# Higienismo-Chile Thesis Pipeline

Proyecto base para **Esteban Matamala Tapia** (Licenciatura en Historia) orientado al estudio del **higienismo en Chile (ca. 1900–1925)** y el rol de la **prensa** (con foco en *Diario El Sur* de Concepción).
El objetivo es **centralizar fuentes en XML**, normalizarlas, analizarlas (palabras clave, KWIC, n-gramas, frecuencias por año/medio) y **generar el manuscrito final en Word** a partir de Markdown.

> Fecha de creación: 2025-09-20

---

## 🧱 Estructura del repositorio

```
.
├─ src/                 # Código fuente (ingesta, procesamiento, análisis)
│  ├─ ingest/           # Parsers y normalizadores
│  ├─ processing/       # Limpieza, normalización, tokenización
│  └─ analysis/         # Herramientas analíticas (KWIC, conteos, coocurrencias)
├─ scripts/             # CLIs que orquestan pasos (build, análisis, export)
├─ data/
│  ├─ raw/              # XML/TEI/RIS/BibTeX originales (NO tocar)
│  ├─ interim/          # Transformaciones intermedias (JSON, TXT)
│  └─ processed/        # Resultados finales listos para análisis
├─ configs/             # Términos, listados de stopwords, reglas
├─ notebooks/           # Exploraciones y prototipos
├─ thesis/              # Redacción de la tesis (Markdown -> Word)
├─ docs/                # Plan de proyecto, guías, decisiones
└─ .github/workflows/   # (Opcional) CI para validaciones simples
```

---

## 🚀 Flujo de trabajo

1) **Recolectar fuentes**
   - Descarga XML de SciELO / Google Scholar (o exporta BibTeX/RIS y luego baja PDFs/XML).
   - Guarda *todo* en `data/raw/` sin modificar nombres.

2) **Construir corpus**
   - Convertir XML (SciELO o TEI) a JSONL normalizado (1 documento por línea):
     ```bash
     python scripts/build_corpus.py --in data/raw --out data/interim/corpus.jsonl
     ```

3) **Limpieza y normalización**
   - Limpiar y tokenizar texto, quitar ruido, estandarizar fechas y autores:
     ```bash
     python scripts/clean_corpus.py --in data/interim/corpus.jsonl --out data/processed/corpus_clean.jsonl
     ```

4) **Análisis**
   - Conteos de términos/temas definidos en `configs/terms.yml`:
     ```bash
     python scripts/compute_counts.py --in data/processed/corpus_clean.jsonl --terms configs/terms.yml --out data/processed/term_counts.csv
     ```
   - KWIC (concordancias) para términos clave:
     ```bash
     python scripts/kwic.py --in data/processed/corpus_clean.jsonl --term higienismo --window 8 --out data/processed/kwic_higienismo.csv
     ```

5) **Citas y bibliografía**
   - Exportar citas desde BibTeX/RIS a CSV legible:
     ```bash
     python scripts/export_citations_csv.py --in data/raw --out data/processed/citas.csv
     ```

6) **Redacción**
   - Escribe en `thesis/thesis_outline.md` y `thesis/manuscrito.md`.
   - Convierte a Word con **Pandoc** (instalar en tu PC):
     ```bash
     pandoc thesis/manuscrito.md -o thesis/manuscrito.docx --reference-doc=thesis/plantilla.docx
     ```
   - Si no usas Pandoc, copia el contenido a Word y aplica la plantilla institucional.

---

## 🧪 Requisitos (sugeridos)
- Python 3.10+
- Instalar dependencias:
  ```bash
  python -m venv .venv
  source .venv/bin/activate  # Windows: .venv\Scripts\activate
  pip install -r requirements.txt
  ```

---

## 📌 Enfoque de investigación (resumen)
- **Pregunta central:** ¿Cómo construyó la prensa chilena (especialmente *El Sur*) el discurso del **higienismo** entre 1900 y 1925?
- **Subpreguntas:**
  - ¿Qué temas (vivienda, salubridad, higiene escolar, campañas sanitarias) aparecen con mayor frecuencia y en qué periodos?
  - ¿Qué actores (médicos, autoridades, municipalidades) son más citados?
  - ¿Cómo varía el tono/valoración (positivo/negativo/neutral) hacia políticas higienistas?
- **Unidades de análisis:** artículos de prensa, editoriales, avisos, informes públicos.
- **Recursos:** XML SciELO/TEI, exportaciones de catálogos, hemerotecas.

---

## 🧰 Consejos
- Mantén **todo lo original** en `data/raw`. No edites esos archivos.
- Las transformaciones siempre generan nuevos archivos con fecha/hora si es posible.
- Documenta hallazgos en `docs/` y decisiones metodológicas.
