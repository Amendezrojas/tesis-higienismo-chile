#!/usr/bin/env python
import argparse, json, pathlib
from src.processing.clean_text import basic_clean

def main():
    ap = argparse.ArgumentParser(description="Limpia y normaliza corpus JSONL.")
    ap.add_argument("--in", dest="inp", required=True, help="archivo .jsonl de entrada")
    ap.add_argument("--out", dest="out", required=True, help="archivo .jsonl de salida")
    args = ap.parse_args()

    inp = pathlib.Path(args.inp)
    out = pathlib.Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)

    with inp.open("r", encoding="utf-8") as fin, out.open("w", encoding="utf-8") as fout:
        for line in fin:
            rec = json.loads(line)
            rec["text_clean"] = basic_clean(rec.get("text",""), lower=True)
            fout.write(json.dumps(rec, ensure_ascii=False) + "\n")

if __name__ == "__main__":
    main()
