#!/usr/bin/env python
import argparse, pathlib, csv

# Nota: Mantener simple. Si hay BibTeX/RIS se puede ampliar con librerías externas.
# Por ahora, recorre .xml/.txt con metadatos básicos y produce un CSV mínimo.

def iter_files(root: pathlib.Path):
    for p in root.rglob("*"):
        if p.is_file() and p.suffix.lower() in {".xml", ".txt"}:
            yield p

def extract_minimal(p: pathlib.Path):
    title = ""
    year = ""
    journal = ""
    try:
        import xml.etree.ElementTree as ET
        root = ET.parse(p).getroot()
        title = root.findtext(".//article-title") or root.findtext(".//title") or ""
        year = root.findtext(".//year") or ""
        journal = root.findtext(".//journal-title") or ""
    except Exception:
        # Para .txt o XML no-JATS, dejar vacío
        pass
    return {"path": str(p), "title": title, "year": year, "container": journal}

def main():
    ap = argparse.ArgumentParser(description="Exporta citas mínimas a CSV desde archivos en data/raw.")
    ap.add_argument("--in", dest="inp", required=True, help="Carpeta de entrada (data/raw)")
    ap.add_argument("--out", dest="out", required=True, help="CSV de salida")
    args = ap.parse_args()

    root = pathlib.Path(args.inp)
    rows = [extract_minimal(p) for p in iter_files(root)]

    outp = pathlib.Path(args.out)
    outp.parent.mkdir(parents=True, exist_ok=True)
    with open(outp, "w", newline="", encoding="utf-8") as csvf:
        w = csv.DictWriter(csvf, fieldnames=["path","title","year","container"])
        w.writeheader()
        w.writerows(rows)

if __name__ == "__main__":
    main()
