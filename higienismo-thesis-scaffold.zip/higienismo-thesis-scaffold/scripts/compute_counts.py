#!/usr/bin/env python
import argparse, json, pathlib, csv, yaml
from collections import Counter, defaultdict

def tokenize(text: str):
    # tokenización mínima
    out, buff = [], []
    for ch in text:
        if ch.isalnum() or ch in "áéíóúüñÁÉÍÓÚÜÑ":
            buff.append(ch.lower())
        else:
            if buff:
                out.append("".join(buff))
                buff = []
    if buff:
        out.append("".join(buff))
    return out

def main():
    ap = argparse.ArgumentParser(description="Conteos de términos por grupos definidos en YAML.")
    ap.add_argument("--in", dest="inp", required=True)
    ap.add_argument("--terms", required=True)
    ap.add_argument("--out", dest="out", required=True)
    args = ap.parse_args()

    cfg = yaml.safe_load(open(args.terms, "r", encoding="utf-8"))
    groups = cfg.get("groups", {})
    stop_extra = set(cfg.get("stopwords_extra", []))

    totals = Counter()
    group_counts = Counter()
    docs = 0

    with open(args.inp, "r", encoding="utf-8") as f:
        for line in f:
            rec = json.loads(line)
            tokens = [t for t in tokenize(rec.get("text_clean","")) if t not in stop_extra]
            totals.update(tokens)
            # grupos
            found = set()
            for g, terms in groups.items():
                for t in terms:
                    if t.lower() in tokens:
                        found.add(g); break
            for g in found:
                group_counts[g] += 1
            docs += 1

    outp = pathlib.Path(args.out)
    outp.parent.mkdir(parents=True, exist_ok=True)
    with open(outp, "w", newline="", encoding="utf-8") as csvf:
        w = csv.writer(csvf)
        w.writerow(["group","docs_with_group","total_docs"])
        for g in groups.keys():
            w.writerow([g, group_counts.get(g,0), docs])

if __name__ == "__main__":
    main()
