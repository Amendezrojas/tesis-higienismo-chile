#!/usr/bin/env python
import argparse, json, pathlib, csv
from src.analysis.kwic import kwic

def tokenize_simple(s: str):
    return s.split()

def main():
    ap = argparse.ArgumentParser(description="Genera KWIC para un término.")
    ap.add_argument("--in", dest="inp", required=True)
    ap.add_argument("--term", required=True)
    ap.add_argument("--window", type=int, default=8)
    ap.add_argument("--out", dest="out", required=True)
    args = ap.parse_args()

    rows = []
    with open(args.inp, "r", encoding="utf-8") as f:
        for line in f:
            rec = json.loads(line)
            text = rec.get("text_clean","")
            tokens = tokenize_simple(text)
            for row in kwic(tokens, args.term, window=args.window):
                rows.append([rec.get("title",""), rec.get("year",""), row["left"], row["term"], row["right"]])

    outp = pathlib.Path(args.out)
    outp.parent.mkdir(parents=True, exist_ok=True)
    with open(outp, "w", newline="", encoding="utf-8") as csvf:
        w = csv.writer(csvf)
        w.writerow(["title","year","left","term","right"])
        w.writerows(rows)

if __name__ == "__main__":
    main()
