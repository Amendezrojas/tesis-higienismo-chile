#!/usr/bin/env python
import argparse, json, pathlib, sys
from src.ingest.scielo_xml import parse_scielo_xml

def iter_paths(root: pathlib.Path):
    for p in root.rglob("*"):
        if p.is_file() and p.suffix.lower() in {".xml"}:
            yield p

def main():
    ap = argparse.ArgumentParser(description="Construye corpus JSONL desde XML (SciELO/TEI).")
    ap.add_argument("--in", dest="inp", required=True, help="Carpeta con XML")
    ap.add_argument("--out", dest="out", required=True, help="Ruta de salida .jsonl")
    args = ap.parse_args()

    root = pathlib.Path(args.inp)
    out = pathlib.Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)

    with out.open("w", encoding="utf-8") as f:
        for path in iter_paths(root):
            try:
                rec = parse_scielo_xml(str(path))
                f.write(json.dumps(rec, ensure_ascii=False) + "\n")
            except Exception as e:
                sys.stderr.write(f"[WARN] No se pudo parsear {path}: {e}\n")

if __name__ == "__main__":
    main()
