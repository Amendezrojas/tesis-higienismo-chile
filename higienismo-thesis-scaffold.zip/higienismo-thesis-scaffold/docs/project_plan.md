# Plan del Proyecto

## Objetivo
Construir un pipeline reproducible para recolectar, normalizar y analizar textos de prensa sobre higienismo en Chile (1900–1925), con entregable final en Word.

## Hitos
1) Corpus mínimo viable (XML -> JSONL)  
2) Limpieza y normalización  
3) Conteos y KWIC  
4) Redacción y conversión a Word  
5) Revisión académica

## Criterios de calidad
- Reproducibilidad: scripts con CLI y logs.
- Trazabilidad: conservar `data/raw` intacto y documentar transformaciones.
- Validación: muestreos manuales del 5–10% del corpus.
