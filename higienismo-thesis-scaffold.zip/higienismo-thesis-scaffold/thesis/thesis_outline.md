# Tesis (borrador): Higienismo y Prensa en Chile (1900–1925)

**Autor:** Esteban Matamala Tapia  
**Tutor:** *(por definir)*  
**Carrera:** Licenciatura en Historia  
**Tema:** El discurso higienista y su configuración en la prensa chilena, con foco en *El Sur* (Concepción).

## 1. Introducción
- Contexto histórico (urbanización, epidemias, políticas sanitarias).
- Relevancia del higienismo como paradigma técnico-político.
- La prensa como espacio de construcción de opinión pública.
- Objetivos y preguntas de investigación.

## 2. Estado del Arte
- Principales obras y líneas interpretativas.
- Brechas: falta de análisis comparativo y seriado de prensa regional.

## 3. Fuentes y Metodología
- Corpus: artículos/editoriales/avisos (1900–1925).
- Estandarización en **XML/TEI** y normalización a **JSONL**.
- Métricas: frecuencias, KWIC, n-gramas, coocurrencias por año/medio.
- Enfoque mixto: cuantitativo (conteos) + cualitativo (lecturas dirigidas).

## 4. Resultados esperados (guía)
- Periodización de oleadas higienistas.
- Temas dominantes (vivienda, higiene escolar, campañas).
- Actores clave y redes institucionales.

## 5. Discusión
- Comparación con historiografía previa.
- La particularidad de prensa regional vs capitalina.

## 6. Conclusiones
- Aportes, límites y futuras líneas de investigación.

## Anexos
- Diccionarios de términos, muestras KWIC, tablas de frecuencias.
