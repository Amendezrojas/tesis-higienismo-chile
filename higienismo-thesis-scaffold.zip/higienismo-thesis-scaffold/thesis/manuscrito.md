---
title: "El higienismo en la prensa chilena (1900–1925): El caso de *El Sur* de Concepción"
author: "Esteban Matamala Tapia"
date: ""
---

# Introducción

*(Escribe aquí. Usa los reportes de `data/processed/` para tablas y figuras.)*

# Fuentes y Método

# Resultados

# Discusión

# Conclusiones

# Referencias
